-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 13, 2020 at 01:03 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopatslot`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `customerId` int(8) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(15) NOT NULL,
  `Email_Id` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `longitude` float NOT NULL,
  `lattitude` float NOT NULL,
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `Email_Id` (`Email_Id`),
  UNIQUE KEY `customerId` (`customerId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerId`, `customer_name`, `Email_Id`, `address`, `longitude`, `lattitude`) VALUES
(2, 'ret', 'fdnc@gmail.com', 'dghg', 0, 0),
(3, 'cdf', 'fdnac@gmail.com', 'bfbfb', 0, 0),
(5, 'sfszfaz', 'f12nc@gmail.com', 'sfsfs', 0, 0),
(6, 'sujitha', 'suj@gmail.com', 'mig 884 plot no 101 kphb hyderabad', 78.4867, 17.385);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `ID` int(15) NOT NULL AUTO_INCREMENT,
  `Email_Id` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`Email_Id`),
  UNIQUE KEY `Email_Id` (`Email_Id`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Email_Id`, `password`, `type`) VALUES
(25, '123@hmsmnd.com', 'dweqa', 'shopkeeper'),
(27, '145@hmsmnd.com', 'dws', 'shopkeeper'),
(7, 'abc@gmail.com', 'sdvbd', 'shopkeeper'),
(17, 'abcd@gmail.com', '1234', 'shopkeeper'),
(8, 'def@gmail.com', '1234', 'shopkeeper'),
(13, 'dgdsbs@gmail.com', 'oij', 'shopkeeper'),
(16, 'dgsdvg@gmail.com', 'dgsgs', 'shopkeeper'),
(15, 'email@gmail.com', '1234', 'shopkeeper'),
(5, 'f12nc@gmail.com', 'fdgved', 'customer'),
(2, 'fdnac@gmail.com', 'vcbfb', 'customer'),
(1, 'fdnc@gmail.com', 'esfsg', 'customer'),
(14, 'hhdfhgfd@gmail.com', 'dgdx', 'shopkeeper'),
(12, 'mar@gmail.com', '1234', 'shopkeeper'),
(31, 'po@gmail.com', '1234', 'shopkeeper'),
(34, 'poppppppp@gmail.com', '1234', 'shopkeeper'),
(21, 'qwr@gmail.com', '324', 'shopkeeper'),
(20, 'rty@gmail.com', '1234', 'shopkeeper'),
(11, 'suj@gmail.com', '1234', 'customer'),
(23, 'uy@gmail.com', '1234', 'shopkeeper'),
(28, 'vip@gmail.com', '1234', 'shopkeeper'),
(30, 'vipuy@gmail.com', 's43r5w', 'shopkeeper'),
(22, 'zyx@gmail.com', '987', 'shopkeeper');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

DROP TABLE IF EXISTS `shop`;
CREATE TABLE IF NOT EXISTS `shop` (
  `shopId` int(15) NOT NULL AUTO_INCREMENT,
  `shop_name` varchar(20) NOT NULL,
  `Email_Id` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `longitude` float DEFAULT NULL,
  `lattitude` float DEFAULT NULL,
  `start` time NOT NULL,
  `end` time NOT NULL,
  PRIMARY KEY (`shopId`),
  UNIQUE KEY `Email_Id` (`Email_Id`),
  UNIQUE KEY `address` (`address`),
  UNIQUE KEY `shopId` (`shopId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`shopId`, `shop_name`, `Email_Id`, `address`, `longitude`, `lattitude`, `start`, `end`) VALUES
(3, 'abc', 'def@gmail.com', '13wds', NULL, NULL, '02:02:00', '14:04:00'),
(4, 'market', 'mar@gmail.com', '123443tsgs', NULL, NULL, '03:22:00', '02:03:00'),
(5, 'shopname', 'email@gmail.com', 'rewesfsvgs', NULL, NULL, '03:22:00', '16:35:00'),
(6, 'fsfs', 'dgsdvg@gmail.com', 'dgsdgxbs', NULL, NULL, '02:25:00', '15:53:00'),
(7, 'dgxdvs', 'abcd@gmail.com', 'dsg', NULL, NULL, '02:07:00', '05:35:00'),
(8, 'abc', 'rty@gmail.com', 'qewsda', NULL, NULL, '03:43:00', '02:05:00'),
(9, 'esg', 'qwr@gmail.com', 'erye', NULL, NULL, '10:59:00', '00:00:00'),
(10, 'zyx', 'zyx@gmail.com', 'mig567', NULL, NULL, '01:00:00', '01:00:00'),
(11, 'yu', 'uy@gmail.com', 'werdhe', NULL, NULL, '13:59:00', '13:59:00'),
(12, 'dsad', '145@hmsmnd.com', 'dwd', NULL, NULL, '01:00:00', '01:00:00'),
(13, 'abvf', 'vipuy@gmail.com', 'wfdsgbfjmgmg', 78.4867, 17.385, '02:00:00', '05:00:00'),
(14, 'poiuy', 'poppppppp@gmail.com', 'gfghjbj', 78.4867, 17.385, '01:00:00', '01:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `shopproduct`
--

DROP TABLE IF EXISTS `shopproduct`;
CREATE TABLE IF NOT EXISTS `shopproduct` (
  `Email_Id` varchar(20) NOT NULL,
  `productid` int(15) NOT NULL AUTO_INCREMENT,
  `productName` varchar(25) NOT NULL,
  `quantity` int(3) NOT NULL,
  `cost` float NOT NULL,
  PRIMARY KEY (`Email_Id`,`productid`,`productName`),
  UNIQUE KEY `productid` (`productid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopproduct`
--

INSERT INTO `shopproduct` (`Email_Id`, `productid`, `productName`, `quantity`, `cost`) VALUES
('def@gmail.com', 11, 'qwerr', 14, 14),
('def@gmail.com', 13, 'iuy', 45, 60),
('def@gmail.com', 16, 'abc', 10, 20),
('def@gmail.com', 18, 'oil', 34, 56),
('def@gmail.com', 19, 'rt', 35, 53);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `fk_cust_Email_Id` FOREIGN KEY (`Email_Id`) REFERENCES `login` (`Email_Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shop`
--
ALTER TABLE `shop`
  ADD CONSTRAINT `fk_shop_Email_Id` FOREIGN KEY (`Email_Id`) REFERENCES `login` (`Email_Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shopproduct`
--
ALTER TABLE `shopproduct`
  ADD CONSTRAINT `fk_shopEmail_id` FOREIGN KEY (`Email_Id`) REFERENCES `shop` (`Email_Id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
