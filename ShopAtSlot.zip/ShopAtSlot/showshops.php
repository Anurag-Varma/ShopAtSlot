
<?php
$JSON=file_get_contents("http://localhost/hackathon/api/customer/update_longlat.php
");
$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode($JSON, TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);
foreach ($jsonIterator as $key => $val) {
    if(!is_array($val)) {
        if($key == "shopid") {
            print "<br/>";
        }
    print $key."    : ".$val . "<br/>";
	//<button type="button">click</button>
echo '<form name="Patient">';
echo '<input type="submit" value="Click here to view patient history">';
echo '</form>';
    }
}


?>