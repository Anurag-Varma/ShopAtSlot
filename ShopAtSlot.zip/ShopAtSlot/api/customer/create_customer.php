<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	header('Access-Control-Allow-Methods:POST');
	header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,x-Requested-With');
	
	include_once '../../config/Database.php';
	include_once '../../models/Logins.php';
	include_once '../../models/Customers.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$login= new Logins($db);
	$customer= new Customers($db);
	
	$customer_name=$_REQUEST['data_1'];
	$email=$_REQUEST['data_5'];
	$pass=$_REQUEST['data_6'];
	//$longi=43;
	//$latti=23;
	$address=$_REQUEST['data_4'];
	

	$login->Email_Id=$email;
	$login->password=$pass;
	$login->type="customer";
	$customer->customer_name=$customer_name;
	$customer->Email_Id=$email;
	//$shop->longi=$longi;
	//$shop->latti=$latti;
	$customer->address=$address;
	
	
	
	
	
		if($login->create() and $customer->create()){
		echo json_encode(array('message'=>'created'));
header("Location:http://localhost/hackathon/login.html");
		}
	
	else{
		$login->delete();
		echo json_encode(array('message'=>'not created'));
		header("Location:http://localhost/hackathon/login.html");
	}
	
	
?>