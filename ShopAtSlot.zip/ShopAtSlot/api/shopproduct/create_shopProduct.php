<?php
	session_start();
?>
	<?php
	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	header('Access-Control-Allow-Methods:POST');
	header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,x-Requested-With');
	
	include_once '../../config/Database.php';

	include_once '../../models/Products.php';
	
	$database=new Database();
	$db=$database->connect();
	
	
	$product= new Products($db);
	
	
	$productName=$_REQUEST['itemname'];
	$quantity=$_REQUEST['quantity'];
	$cost=$_REQUEST['Cost'];
	
	$product->productName=$productName;
	$product->quantity=$quantity;
	$product->cost=$cost;
	
	
	
	
	if($product->create() ){
		echo json_encode(array('message'=>'created'));
	}
	else{
		echo json_encode(array('message'=>'not created'));
	}
	
	
?>