<?php
	session_start();
?>
	<?php
	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	header('Access-Control-Allow-Methods:POST');
	header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,x-Requested-With');
	
	include_once '../../config/Database.php';

	include_once '../../models/Products.php';
	
	$database=new Database();
	$db=$database->connect();
	
	
	$product= new Products($db);
	
	
	$productName=$_REQUEST['itemname'];
	
	
	$product->productName=$productName;
	
	
	
	
	
	if($product->delete() ){
		echo json_encode(array('message'=>'deleted'));
	}
	else{
		echo json_encode(array('message'=>'not deleted'));
	}
	
	
?>