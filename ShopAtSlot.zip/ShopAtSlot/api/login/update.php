<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	header('Access-Control-Allow-Methods:PUT');
	header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,x-Requested-With');
	
	include_once '../../config/Database.php';
	include_once '../../models/Logins.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$login= new Logins($db);
	
	$data= json_decode(file_get_contents("php://input"));
	
	$login->Email_Id=$data->Email_Id;
	$login->password=$data->password;
	$login->type=$data->type;
	
	if($login->update()){
		echo json_encode(array('message'=>'updated'));
	}
	else{
		echo json_encode(array('message'=>'not updated'));
	}
	
	
?>