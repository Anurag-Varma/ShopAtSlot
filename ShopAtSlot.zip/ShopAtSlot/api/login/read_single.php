<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	
	include_once '../../config/Database.php';
	include_once '../../models/Logins.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$login= new Logins($db);
	
	$login->id=isset($_GET['id'])?$_GET['id']:die();
	
	$login->read_single();
	
	$login_arr=array(
	'id'=>$login->id,
	'Email_Id'=>$login->Email_Id,
	'password'=>$login->password,
	'type'=>$login->type
	);
	
	
	print_r(json_encode($login_arr));
		
		
?>