<?php

	session_start();
	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	header('Access-Control-Allow-Methods:DELETE');
	header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,x-Requested-With');
	
	include_once '../../config/Database.php';
	include_once '../../models/Logins.php';
	include_once '../../models/Shops.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$login= new Logins($db);
	
	$email=$_REQUEST['username'];
	$pass=$_REQUEST['password'];
	
	//$data= json_decode(file_get_contents("php://input"));
	
	//$login->Email_Id=$data->Email_Id;
	//$login->password=$data->password;

	$login->Email_Id=$email;
	$login->password=$pass;
	$result=$login->check();
	$num=$result->rowcount();
	
	if($num==1){
		//echo json_encode(array('message'=>'logins found'));
		/*setcookie("Email_Id",$email,time()+2*24*60*60);
		echo $_COOKIE["Email_Id"];*/
		$_SESSION["Email_Id"]=$email;
		$row=$result->fetch(PDO::FETCH_ASSOC);
		extract($row);
		 //echo json_encode($type);
		
		if($type=="customer")
			//header("Location:http://localhost/hackathon/basic.php");
			header("Location:http://localhost/hackathon/logincustomer.html");
			
			
		else if($type=="shopkeeper")
			//header("Location:http://localhost/hackathon/ShopKeeperAdd.html");
		header("Location:http://localhost/hackathon/loginshopkeeper.html");
		
	}
	else{
		echo json_encode(array('message'=>'no logins found'));
		header("Location:http://localhost/hackathon/login.html");
	}
	
	
?>