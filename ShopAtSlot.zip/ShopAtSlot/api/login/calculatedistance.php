<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	
	include_once '../../config/Database.php';
	include_once '../../models/Logins.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$logins= new Logins($db);
	
	$result=$logins->read();
	
	$num=$result->rowcount();
	if($num>0){
		$login_arr=array();
		$login_arr['data']=array();
		
		while($row=$result->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			
			$login_item=array(
			'id'=>$id,
			'Email_Id'=>$Email_Id,
	'password'=>$password,
	'type'=>$type);
			
			array_push($login_arr['data'],$login_item);
			
		}
		echo json_encode($login_arr);
	}else{
		
		echo json_encode(array('message'=>'no logins found'));
	}
		
?>