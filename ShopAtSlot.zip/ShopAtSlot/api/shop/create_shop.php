<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	header('Access-Control-Allow-Methods:POST');
	header('Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization,x-Requested-With');
	
	include_once '../../config/Database.php';
	include_once '../../models/Logins.php';
	include_once '../../models/Shops.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$login= new Logins($db);
	$shop= new Shops($db);
	
	$shop_name=$_REQUEST['data_1'];
	$email=$_REQUEST['data_2'];
	$pass=$_REQUEST['data_4'];
	$longi=$_REQUEST['longitude'];
	$latti=$_REQUEST['latitude'];
	
	$address=$_REQUEST['data_5'];
	$starttime=$_REQUEST['opentime'];
	$endtime=$_REQUEST['closetime'];

	$login->Email_Id=$email;
	$login->password=$pass;
	$login->type="shopkeeper";
	$shop->shop_name=$shop_name;
	$shop->Email_Id=$email;
	$shop->longi=$longi;
	$shop->latti=$latti;
	$shop->address=$address;
	$shop->starttime=$starttime;
	$shop->endtime=$endtime;
	
	
	
	
		if($login->create() and $shop->create()){
		echo json_encode(array('message'=>'created'));
		header("Location:http://localhost/hackathon/login.html");
		}

	else{
		$login->delete();
		echo json_encode(array('message'=>'not created'));
		header("Location:http://localhost/hackathon/login.html");
	}
	
	
?>