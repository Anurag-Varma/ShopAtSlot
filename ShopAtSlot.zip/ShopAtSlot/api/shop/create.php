
<?php
echo $shop_name=$_REQUEST['longi'];
?>