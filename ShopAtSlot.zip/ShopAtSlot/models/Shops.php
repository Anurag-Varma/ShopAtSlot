<?php
	class Shops{
		private $conn;
		private $table='shop';

		public $shopid;
		public $shop_name;
		public $Email_Id;
		public $longi;
		public $latti;
		public $address;
		public $starttime;
		public $endtime;
		
		public function __construct($db){
			$this->conn=$db;
		}
		
	public function create(){
			$query='INSERT INTO shop Set  shop_name=:shop_name,Email_Id=:Email_Id,longitude=:longi,lattitude=:latti,address= :address,start=:starttime,end=:endtime';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->shop_name=htmlspecialchars(strip_tags($this->shop_name));
			$this->longi=htmlspecialchars(strip_tags($this->longi));
			$this->latti=htmlspecialchars(strip_tags($this->latti));
			$this->address=htmlspecialchars(strip_tags($this->address));
			$this->starttime=htmlspecialchars(strip_tags($this->starttime));
			$this->endtime=htmlspecialchars(strip_tags($this->endtime));
			
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':shop_name',$this->shop_name);
			$stmt->bindParam(':longi',$this->longi);
			$stmt->bindParam('latti',$this->latti);
			$stmt->bindParam(':address',$this->address);
			$stmt->bindParam('starttime',$this->starttime);
			$stmt->bindParam('endtime',$this->endtime);

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
	public function update(){
			$query='UPDATE shop Set  shop_name=:shop_name,Email_Id=:Email_Id,address= :address,start=:starttime,end=:endtime';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->shop_name=htmlspecialchars(strip_tags($this->shop_name));
			//$this->longi=htmlspecialchars(strip_tags(longi));
		//	$this->latti=htmlspecialchars(strip_tags($this->latti));
			$this->address=htmlspecialchars(strip_tags($this->address));
			$this->starttime=htmlspecialchars(strip_tags($this->starttime));
			$this->endtime=htmlspecialchars(strip_tags($this->endtime));
			
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':shop_name',$this->shop_name);
			//$stmt->bindParam(':longi',$this->longi);
			//$stmt->bindParam('latti',$this->latti);
			$stmt->bindParam(':address',$this->address);
			$stmt->bindParam('starttime',$this->starttime);
			$stmt->bindParam('endtime',$this->endtime);

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
		public function read(){
			//create query
			$query='select  shopid,shop_name,Email_Id,address,longitude,lattitude,start,end  from shop';
			
			$stmt=$this->conn->prepare($query);
			$stmt->execute();
			return $stmt;
		}
		/*
		public function delete(){
			$query=' delete from login where Email_Id= :Email_Id and password=:password';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
		
		public function check(){


			//create query
			$query='select  type  from login where Email_Id= :Email_Id and password=:password';
			
			$stmt=$this->conn->prepare($query);
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			$stmt->execute();
			return $stmt;
			/* $num=$stmt->rowcount();
			 
			 if($num>0){
				 return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;*/
		//}
		
		
			
	}
?>	