

<?php
	class Customers{
		private $conn;
		private $table='customer';

		public $customerid;
		public $customer_name;
		public $Email_Id;
		public $longi;
		public $latti;
		public $address;
		
		
		public function __construct($db){
			$this->conn=$db;
		}
		
	public function create(){
			$query='INSERT INTO customer Set  customer_name=:customer_name,Email_Id=:Email_Id,address= :address';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->customer_name=htmlspecialchars(strip_tags($this->customer_name));
			//$this->longi=htmlspecialchars(strip_tags(longi));
		//	$this->latti=htmlspecialchars(strip_tags($this->latti));
			$this->address=htmlspecialchars(strip_tags($this->address));
			
			
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':customer_name',$this->customer_name);
			//$stmt->bindParam(':longi',$this->longi);
			//$stmt->bindParam('latti',$this->latti);
			$stmt->bindParam(':address',$this->address);
			

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
	public function update(){
			$query='UPDATE customer Set  customer_name=:customer_name,address= :address where Email_Id=:Email_Id';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->customer_name=htmlspecialchars(strip_tags($this->customer_name));
			//$this->longi=htmlspecialchars(strip_tags(longi));
		//	$this->latti=htmlspecialchars(strip_tags($this->latti));
			$this->address=htmlspecialchars(strip_tags($this->address));
			
			
			
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':customer_name',$this->customer_name);
			//$stmt->bindParam(':longi',$this->longi);
			//$stmt->bindParam('latti',$this->latti);
			$stmt->bindParam(':address',$this->address);
			

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
		
		public function update_longlat(){
			$query='UPDATE customer Set  longitude=:longi,lattitude= :latti where Email_Id=:Email_Id';
			
			$stmt=$this->conn->prepare($query);
			
			
			$this->longi=htmlspecialchars(strip_tags($this->longi));
			$this->latti=htmlspecialchars(strip_tags($this->latti));
			
			
			
			
			$this->Email_Id=$_SESSION["Email_Id"];
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':longi',$this->longi);
			$stmt->bindParam('latti',$this->latti);
			
			

			if($stmt->execute()){
				
				$query='select s.shopId,s.Email_Id,s.shop_name,s.longitude,s.address,s.lattitude,s.address,s.start,s.end from shop s';
				
				$stmt=$this->conn->prepare($query);
			$stmt->execute();
			$result=$stmt;
			$num=$result->rowcount();
			//echo $num;
	if($num>0){
		$shop_arr=array();
		$shop_arr['data']=array();
		
		
		
		while($row=$result->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			
			if($this->distance($longitude,$lattitude,$this->longi,$this->latti)>2){
				
					print "\n";
					print "\tshopID:".$shopId."\n\t".'Shop_Name:'.$shop_name."\n"."\tShop Address:".$address."\n\tStart Time:".$start."\t End Time:". $end."\n";
			}
			
		}
		
		}
		}
		else 
			echo  json_encode(array('message'=>'no shops found'));
	}
		
		public function distance($lat1, $lon1, $lat2, $lon2) {

    $pi80 = M_PI / 180;
    $lat1 *= $pi80;
    $lon1 *= $pi80;
    $lat2 *= $pi80;
    $lon2 *= $pi80;

    $r = 6372.797; // mean radius of Earth in km
    $dlat = $lat2 - $lat1;
    $dlon = $lon2 - $lon1;
    $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlon / 2) * sin($dlon / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    $km = $r * $c;

    //echo '<br/>'.$km;
    return $km;
		}
		
		public function read(){
			//create query
			$query='select  customerid,customer_name,Email_Id,address  from customer';
			
			$stmt=$this->conn->prepare($query);
			$stmt->execute();
			return $stmt;
		}
	
			
	}
?>
