
<?php
	class Products{
		private $conn;
		private $table='shopproduct';
		
		public $shopid;
		public $productName;
		public $quantity;
		public $cost;
		
		public function __construct($db){
			$this->conn=$db;
		}
		
		
	/*	public function read_single(){
		$query='select id,Email_Id,password,type from login where Email_Id=?';
		$stmt=$this->conn->prepare($query);
		$stmt->bindParam(1,$this->Email_Id);
		$stmt->execute();
		$row=$stmt->fetch(PDO::FETCH_ASSOC);
		
		//$this->Email_Id=$row['Email_Id'];
		$this->password=$row['password'];
		$this->type=$row['type'];
		
	}*/
	public function read(){
			//create query
			$query='select  productid,productName,quantity,cost  from shopproduct';
			
			$stmt=$this->conn->prepare($query);
			
			//$this->shopid=$_SESSION["Email_Id"];
			//$stmt->bindParam(':shopid',$this->shopid);
			
			$stmt->execute();
			return $stmt;
		}
	public function create(){
			//echo $_SESSION["Email_Id"];
				
				//echo $shopid;
			$query='INSERT INTO shopproduct Set  Email_id= :shopid,productName= :productName,quantity= :quantity,cost= :cost';
			
			$stmt=$this->conn->prepare($query);
			//echo $query;
			$this->shopid=$_SESSION["Email_Id"];
			$this->productName=htmlspecialchars(strip_tags($this->productName));
			//$this->longi=htmlspecialchars(strip_tags(longi));
		//	$this->latti=htmlspecialchars(strip_tags($this->latti));
			$this->quantity=htmlspecialchars(strip_tags($this->quantity));
			$this->cost=htmlspecialchars(strip_tags($this->cost));
			
			
			$stmt->bindParam(':shopid',$this->shopid);
			$stmt->bindParam(':productName',$this->productName);
			//$stmt->bindParam(':longi',$this->longi);
			//$stmt->bindParam('latti',$this->latti);
			$stmt->bindParam(':quantity',$this->quantity);
			$stmt->bindParam(':cost',$this->cost);
			

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
	public function update(){
			$query='UPDATE shopproduct Set  quantity= :quantity,cost= :cost WHERE Email_Id=:shopid and productName= :productName';
			
			$stmt=$this->conn->prepare($query);
			//echo $query;
			$this->shopid=$_SESSION["Email_Id"];
			$this->productName=htmlspecialchars(strip_tags($this->productName));
			//$this->longi=htmlspecialchars(strip_tags(longi));
		//	$this->latti=htmlspecialchars(strip_tags($this->latti));
			$this->quantity=htmlspecialchars(strip_tags($this->quantity));
			$this->cost=htmlspecialchars(strip_tags($this->cost));
			
			
			$stmt->bindParam(':shopid',$this->shopid);
			$stmt->bindParam(':productName',$this->productName);
			//$stmt->bindParam(':longi',$this->longi);
			//$stmt->bindParam('latti',$this->latti);
			$stmt->bindParam(':quantity',$this->quantity);
			$stmt->bindParam(':cost',$this->cost);
			

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
		public function delete(){
			$query=' delete from shopproduct where Email_Id= :shopid and productName= :productName';
			
			$stmt=$this->conn->prepare($query);
			
			//echo $query;
			$this->shopid=$_SESSION["Email_Id"];
			$this->productName=htmlspecialchars(strip_tags($this->productName));
			
			$stmt->bindParam(':shopid',$this->shopid);
			$stmt->bindParam(':productName',$this->productName);
			
			
			if($stmt->execute()){
				return true;
			return false;
		}
		}
		
	/*	public function check(){


			//create query
			$query='select  type  from login where Email_Id= :Email_Id and password=:password';
			
			$stmt=$this->conn->prepare($query);
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			$stmt->execute();
			return $stmt;
			/* $num=$stmt->rowcount();
			 
			 if($num>0){
				 return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;*/
		//}
		
		
			
	}
?>	