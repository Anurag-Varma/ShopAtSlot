<?php
	class Logins{
		private $conn;
		private $table='login';
		
		public $id;
		public $password;
		public $Email_Id;
		public $type;
		
		public function __construct($db){
			$this->conn=$db;
		}
		
		
		public function read_single(){
		$query='select id,Email_Id,password,type from login where Email_Id=?';
		$stmt=$this->conn->prepare($query);
		$stmt->bindParam(1,$this->Email_Id);
		$stmt->execute();
		$row=$stmt->fetch(PDO::FETCH_ASSOC);
		
		//$this->Email_Id=$row['Email_Id'];
		$this->password=$row['password'];
		$this->type=$row['type'];
		
	}
	public function create(){
			$query='INSERT INTO login Set  Email_Id=:Email_Id,password= :password,type= :type';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			$this->type=htmlspecialchars(strip_tags($this->type));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			$stmt->bindParam(':type',$this->type);

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
	public function update(){
			$query='UPDATE login Set  password= :password,type= :type WHERE Email_Id=:Email_Id';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			$this->type=htmlspecialchars(strip_tags($this->type));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			$stmt->bindParam(':type',$this->type);

			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
		public function delete(){
			$query=' delete from login where Email_Id= :Email_Id and password=:password';
			
			$stmt=$this->conn->prepare($query);
			
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			if($stmt->execute()){
				return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;
		}
		public function read(){
			//create query
			$query='select  id,Email_Id,password,type  from login';
			
			$stmt=$this->conn->prepare($query);
			$stmt->execute();
			return $stmt;
		}
		public function check(){


			//create query
			$query='select  type  from login where Email_Id= :Email_Id and password=:password';
			
			$stmt=$this->conn->prepare($query);
			$this->Email_Id=htmlspecialchars(strip_tags($this->Email_Id));
			$this->password=htmlspecialchars(strip_tags($this->password));
			
			$stmt->bindParam(':Email_Id',$this->Email_Id);
			$stmt->bindParam(':password',$this->password);
			$stmt->execute();
			return $stmt;
			/* $num=$stmt->rowcount();
			 
			 if($num>0){
				 return true;
			}

			//printf("error:%s.\n",$stmt->error);
			return false;*/
		}
		
		
			
	}
?>	