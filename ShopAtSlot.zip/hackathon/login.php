<?php 

 
$username = $_POST['username'];
$password = $_POST['password'];
 
$username=stripcslashes($username);
$password=stripcslashes($password);

$username=mysqli_real_escape_string($username);
$password=mysqli_real_escape_string($password);  

mysqli_connect("localhost","root","","shopatslot");

$res = mysqli_query("select * from login where username='$username'and password='$password'")
		or die("failed to query database" .mysqli_error());
$result=mysqli_fetch_array($res);
if($result['username']==$username&&$result['password']==$password)
{
	echo "You are login Successfully ";
 
 
	//header("location:my-account.php");   // create my-account.php page for redirection 
	
}
else
{
	echo "login is unsuccessful";
	//header("location:login.php");// if error then redirect to login page . 
}

?>