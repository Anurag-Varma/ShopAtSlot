<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	
	include_once '../../config/Database.php';
	include_once '../../models/Customers.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$customer= new Customers($db);
	
	$result=$customer->read();
	
	$num=$result->rowcount();
	if($num>0){
		$customer_arr=array();
		$customer_arr['data']=array();
		
		while($row=$result->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			
			$shop_item=array(
			'customerid'=>$customerid,
			'customer_name'=>$customer_name,
			'Email_Id'=>$Email_Id,
			'address'=>$address,
			);
			
			array_push($shop_arr['data'],$shop_item);
			
		}
		echo json_encode($shop_arr);
	}else{
		
		echo json_encode(array('message'=>'no shops found'));
	}
		
?>