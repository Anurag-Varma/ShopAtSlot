<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	
	include_once '../../config/Database.php';
	include_once '../../models/Products.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$product= new Products($db);
	
	$result=$product->read();
	
	$num=$result->rowcount();
	if($num>0){
		$product_arr=array();
		$product_arr['data']=array();
		
		while($row=$result->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			
			
			print "\t\n\t".'productID:'.$productid."\n"."\tproductName:".$productName."\n\tQuantity:".$quantity."\n\tcost:". $cost."\n";
			
			
			
		}
		
	}else{
		
		echo json_encode(array('message'=>'no shops found'));
	}
		
?>