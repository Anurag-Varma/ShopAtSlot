<?php

	header('Access-Control-Allow-Origin:*');
	header('Content-Type:application/json');
	
	include_once '../../config/Database.php';
	include_once '../../models/Shops.php';
	
	$database=new Database();
	$db=$database->connect();
	
	$shop= new Shops($db);
	
	$result=$shop->read();
	
	$num=$result->rowcount();
	if($num>0){
		$shop_arr=array();
		$shop_arr['data']=array();
		
		while($row=$result->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			
			$shop_item=array(
			'shopid'=>$shopid,
			'shop_name'=>$shop_name,
			'Email_Id'=>$Email_Id,
			'address'=>$address,
			'start'=>$start,
	'end'=>$end);
			
			array_push($shop_arr['data'],$shop_item);
			
		}
		echo json_encode($shop_arr);
	}else{
		
		echo json_encode(array('message'=>'no shops found'));
	}
		
?>